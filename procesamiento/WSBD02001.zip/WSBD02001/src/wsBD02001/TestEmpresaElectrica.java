package wsBD02001;

import java.io.IOException;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.jasypt.contrib.org.apache.commons.codec_1_3.binary.Base64;

import wsBD02001.com.SolicitaWebServicesURL;


/** Objeto para consumir el web services de la empresa electrica.
 *
 * @author Omar Vélez o.velez@jardinazuayo.fin.ec
 *
 */
public class TestEmpresaElectrica {

    /** Metodo para crear el objeto.
     *
     */
    public TestEmpresaElectrica() {
        super();
    }

    /** Metodo para la ejecución del proceso.
     *
     * @param args
     */
    public static void main(String[] args) {
        SolicitaWebServicesURL solicitaWebServicesURL =
            new SolicitaWebServicesURL() {

            public HttpURLConnection generarConexion() throws MalformedURLException,
                                                              IOException {
                URL url = new URL(getURLConsulta());
                HttpURLConnection connection =
                    (HttpURLConnection)url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("SOAPAction",
                                              "http://sap.com/xi/WebService/soap1.1");
                String credentials = "zrecaudacion:p0o9i8u7";
                String basicAuth =
                    "Basic " + new String(Base64.encodeBase64(credentials.getBytes()));
                System.out.println(basicAuth);
                connection.setRequestProperty("Authorization", basicAuth);
                return connection;
            }
        };

        solicitaWebServicesURL.setTimeOut(30000);
        solicitaWebServicesURL.setURLConsulta("http://190.90.146.178:9090/cis/sap/xi/engine?type=entry&amp;version=3.0&amp;Sender.Service=BS_EXTCASH_DEV&amp;Interface=urn%3Acisnergia.gob.ec%3Acashpoint%3Asapisu%3Aopenitemsummary^SI_OpenSummary_Sync_Out");
        solicitaWebServicesURL.setXMLConsulta("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:glob=\"http://sap.com/xi/SAPGlobal/Global\"><soapenv:Header/><soapenv:Body><glob:CashPointOpenItemSummaryByElementsQueryMessage><MessageHeader><ID></ID><CreationDateTime>2016-05-25T13:20:00Z</CreationDateTime></MessageHeader><CashPointOpenItemSummaryByElementsQuery><CashPointReferenceID>CAEX-B03-C2-1002</CashPointReferenceID><CashPointOfficeReferenceID>OFEX-B03-BOLIVA</CashPointOfficeReferenceID><SelectionByContractAccountID>200000108551</SelectionByContractAccountID><SelectionContractAccountIDLegacy></SelectionContractAccountIDLegacy></CashPointOpenItemSummaryByElementsQuery></glob:CashPointOpenItemSummaryByElementsQueryMessage></soapenv:Body></soapenv:Envelope>");

        try {
            solicitaWebServicesURL.ejecutarConsultaWebService();
        } catch (Exception e) {
            System.out.println("Error en la solicitud web service " +
                               e.toString());
        }
        System.out.println(solicitaWebServicesURL.toString());
    }
}

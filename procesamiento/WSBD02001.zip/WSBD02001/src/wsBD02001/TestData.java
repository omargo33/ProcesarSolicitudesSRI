package wsBD02001;


import java.io.StringReader;

import java.util.HashMap;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.xml.sax.InputSource;


/**Objeto para testear la lectura de un web services del DINARDAP.
 *
 * @author omar velez o.velez@jardinazuayo.fin.ec
 *
 */
public class TestData {
    public TestData() {
        super();
    }

    /**
     * M�todo para convertir en un Document, objeto contenedor de un XML.
     *
     * @param in
     * @return
     */
    public Document parseXmlFile(String in) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();            
            InputSource is = new InputSource(new StringReader(in));
            return db.parse(is);
        } catch (Exception e) {
            System.out.println(this.getClass().getName() + " .parseXmlFile() " + e.toString());
            return null;
        }
    }

    /**Metodo para descuartizar los xml del sistema Dinardap.
     *
     * @param contenido
     */
    public void descuartizaXML(String contenido) {
        Document document = parseXmlFile(contenido);
        
        
        
        NodeList nodeLst = document.getElementsByTagName("Table1");


        for (int i = 0; i < nodeLst.getLength(); i++) {
            System.out.println("Fila: " + (i + 1));
            Node nodo = nodeLst.item(i);
            HashMap<String, String> mapaParemetros = new HashMap<String, String>();

            for (int k = 0; k < nodo.getChildNodes().getLength(); k++)
                mapaParemetros.put(nodo.getChildNodes().item(k).getNodeName(),
                                   nodo.getChildNodes().item(k).getTextContent());

            Iterator<String> keySetIterator = mapaParemetros.keySet().iterator();

            while (keySetIterator.hasNext()) {
                String key = keySetIterator.next();
                System.out.println("key: " + key + " value: " + mapaParemetros.get(key));
            }
            System.out.println(mapaParemetros.get("NumTarjeta"));
        }
    }

    /**
     * @param contenido
     * @param tag
     * @return
     */
    public HashMap descuartizaXMLMap(String contenido,String tag) {
        Document document = parseXmlFile(contenido);
        NodeList nodeLst = document.getElementsByTagName(tag);
        HashMap<String, String> mapaParemetros=new HashMap<String, String>();         
        for (int i = 0; i < nodeLst.getLength(); i++) {            
            Node nodo = nodeLst.item(i);
            mapaParemetros = new HashMap<String, String>();
            for (int k = 0; k < nodo.getChildNodes().getLength(); k++)
                mapaParemetros.put(nodo.getChildNodes().item(k).getNodeName(),
                                   nodo.getChildNodes().item(k).getTextContent());                    
        }
        return mapaParemetros;
    }


    /**
     * @param args
     */
    public static void main(String[] args) {
        TestData testData = new TestData();
        String datos="<Table1><NumTarjeta>5058860180000298   </NumTarjeta><Nombre>ANA MARIA GUZMAN              </Nombre><Estado>False</Estado><Clase_estado>False</Clase_estado><Tipo>P</Tipo><Entidad>00</Entidad><FechaIngreso>11/02/2015 0:00:00</FechaIngreso><FechaVencimiento>2502</FechaVencimiento><Motivo>  </Motivo><DesMotivo></DesMotivo><DesEstado>Activa</DesEstado></Table1>";
        testData.descuartizaXML(datos);
        //testData.descuartizaXML(archivoBase.getTexto());
    }
}

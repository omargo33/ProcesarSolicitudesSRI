package wsBD02001;

import wsBD02001.com.SolicitaWebServicesURL;

/**Objeto para probar el web services de inhabilitados.
 *
 * @author omar velez o.velez@jardinazuayo.fin .ec
 *
 */
public class TestWSInhabilitados {
    public TestWSInhabilitados() {
        super();
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        SolicitaWebServicesURL solicitaWebServicesURL = new SolicitaWebServicesURL();
        solicitaWebServicesURL.setTimeOut(10000);
        solicitaWebServicesURL.setURLConsulta("http://172.17.210.139/RCS WS OFAC/Service.asmx");
        solicitaWebServicesURL.setXMLConsulta("<env:Envelope xmlns:env='http://schemas.xmlsoap.org/soap/envelope/' xmlns:ns1='http://localhost/'> <env:Header/> <env:Body> <ns1:BusquedaCheckNames> <ns1:licenciaEmpresa>E863</ns1:licenciaEmpresa> <ns1:nombreABuscar>osama</ns1:nombreABuscar> <ns1:direccion/> <ns1:ciudad/> <ns1:estado/> <ns1:codigoPostal/> <ns1:pais/> <ns1:idPolitica>20140610021639</ns1:idPolitica> <ns1:userName>admin</ns1:userName> <ns1:perfilUsuario>Administrador</ns1:perfilUsuario> <ns1:valoresDefault>RCS</ns1:valoresDefault> <ns1:rutaSetupDB></ns1:rutaSetupDB> <ns1:rutaReportes></ns1:rutaReportes> <ns1:rutaLog></ns1:rutaLog> <ns1:nombreLog>LogErrorWS_OFAC.txt</ns1:nombreLog> <ns1:metodoBusqueda>AUTO</ns1:metodoBusqueda> <ns1:primaryKey/> <ns1:codError>1</ns1:codError> <ns1:descripcionError/> </ns1:BusquedaCheckNames> </env:Body></env:Envelope>");

        try {
            solicitaWebServicesURL.ejecutarConsultaWebService();
        } catch (Exception e) {
            System.out.println("Error en la solicitud web service " + e.toString());
        }
        System.out.println(solicitaWebServicesURL.toString());
    }
}

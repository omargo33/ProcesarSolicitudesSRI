package wsBD02001;

import java.io.IOException;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import wsBD02001.com.SolicitaWebServicesURL;

public class TestIW01001 {
    public TestIW01001() {
        super();
    }

    public static void main(String[] args) {

        //http://172.17.210.144:7015/TC01001-ModelTC01004-context-root/TarjetasChipService?WSDL
        SolicitaWebServicesURL solicitaWebServicesURL =

            new SolicitaWebServicesURL() {

            public HttpURLConnection generarConexion() throws MalformedURLException,
                                                              IOException {
                URL url = new URL(getURLConsulta());
                HttpURLConnection connection =
                    (HttpURLConnection)url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "text/xml");
                return connection;
            }
        };

        solicitaWebServicesURL.setTimeOut(3);
        solicitaWebServicesURL.setURLConsulta("http://localhost:7101/ModelIW01001/IW01001ModuleService?WSDL");
                                               
        
        //solicitaWebServicesURL.setURLConsulta("http://172.17.210.144:7015/TC01001-ModelTC01004-context-root/TarjetasChipService?WSDL");
        solicitaWebServicesURL.setXMLConsulta("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"/modelIW01001/bc/common/types/\" xmlns:ns2=\"/modelIW01001/bc/vistasNoDML/common/\">\n" + 
        "   <env:Header/>\n" + 
        "   <env:Body>\n" + 
        "      <ns1:impresionArchivoFisicio>\n" + 
        
        "         <ns1:parametro>\n" + 
        "            <ns2:Nombre>codigoEmpresa</ns2:Nombre>\n" + 
        "            <ns2:Valor>1</ns2:Valor>\n" + 
        "         </ns1:parametro>\n" + 
        
        "         <ns1:parametro>\n" + 
        "            <ns2:Nombre>codigoUsuario</ns2:Nombre>\n" + 
        "            <ns2:Valor>11</ns2:Valor>\n" + 
        "         </ns1:parametro>\n" + 
        
        "         <ns1:parametro>\n" + 
        "            <ns2:Nombre>codigoSucursal</ns2:Nombre>\n" + 
        "            <ns2:Valor>1</ns2:Valor>\n" + 
        "         </ns1:parametro>\n" + 
        
        "         <ns1:parametro>\n" + 
        "            <ns2:Nombre>codigoImpresion</ns2:Nombre>\n" + 
        "            <ns2:Valor>400</ns2:Valor>\n" + 
        "         </ns1:parametro>\n" + 
                                              
        "         <ns1:parametro>\n" + 
        "            <ns2:Nombre>host</ns2:Nombre>\n" + 
        "            <ns2:Valor>155.155.155.155</ns2:Valor>\n" + 
        "         </ns1:parametro>\n" + 
                                              
        "         <ns1:parametro>\n" + 
        "            <ns2:Nombre>aplicacion</ns2:Nombre>\n" + 
        "            <ns2:Valor>IW01001</ns2:Valor>\n" + 
        "         </ns1:parametro>\n" + 
                                              
        "         <ns1:parametro>\n" + 
        "            <ns2:Nombre>nombreImpresion</ns2:Nombre>\n" + 
        "            <ns2:Valor>holaTarola</ns2:Valor>\n" + 
        "         </ns1:parametro>\n" + 
                                              
        "         <ns1:parametro>\n" + 
        "            <ns2:Nombre>xls</ns2:Nombre>\n" + 
        "            <ns2:Valor/>\n" + 
        "         </ns1:parametro>\n" + 
                                              
                                              
                                              
        "      </ns1:impresionArchivoFisicio>\n" + 
        "   </env:Body>\n" + 
        "</env:Envelope>");
        try {
            solicitaWebServicesURL.ejecutarConsultaWebService();
        } catch (Exception e) {
            System.out.println("Error en la solicitud web service" +
                               e.toString());
        }

        System.out.println(solicitaWebServicesURL.getXMLRespuesta());
        System.out.println(solicitaWebServicesURL.toString());
    }
}

package wsBD02001;

import java.io.IOException;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import wsBD02001.com.SolicitaWebServicesURL;


public class TestTC01001 {
    public TestTC01001() {
        super();
    }

    /**
     * @param args
     */
    public static void main(String[] args) {

        //http://172.17.210.144:7015/TC01001-ModelTC01004-context-root/TarjetasChipService?WSDL
        SolicitaWebServicesURL solicitaWebServicesURL =

            new SolicitaWebServicesURL() {

                public HttpURLConnection generarConexion() throws MalformedURLException, IOException {
                    URL url = new URL(getURLConsulta());
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setRequestProperty("Content-Type", "text/xml");
                    return connection;
                }
            };

        solicitaWebServicesURL.setTimeOut(0);
        solicitaWebServicesURL.setURLConsulta("http://172.17.210.144:7015/TC01001-ModelTC01004-context-root/TarjetasChipService?WSDL");
        solicitaWebServicesURL.setXMLConsulta("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"http://ws.modeltc01004/\"><soapenv:Header/><soapenv:Body><ns1:getListadoTarjetas><identificacion>0104253802</identificacion></ns1:getListadoTarjetas></soapenv:Body></soapenv:envelope>");
        try {
            solicitaWebServicesURL.ejecutarConsultaWebService();
        } catch (Exception e) {
            System.out.println("Error en la solicitud web service" + e.toString());
        }
        
        System.out.println(solicitaWebServicesURL.getXMLRespuesta());
        System.out.println(solicitaWebServicesURL.toString());
    }
}

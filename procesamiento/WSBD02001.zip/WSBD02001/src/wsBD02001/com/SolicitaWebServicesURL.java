package wsBD02001.com;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

import java.util.Date;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;

import org.xml.sax.InputSource;


/** Objeto para hacer una consutal a un web services, directo al stream input del servidor.
 *
 * @author omar velez o.velez@jardinazuayo.fin.ec
 *
 */
@Getter 
@Setter
public class SolicitaWebServicesURL {

    int timeOut;
    int HTTPEstado = 0;
    String mensajeError;
    String XMLConsulta;
    String URLConsulta;
    String XMLRespuesta;
    Document XMLDocument;
    Date fechaInicio;
    Date fechaFin;

    /** M�todo para crear el objeto.
     *
     */
    public SolicitaWebServicesURL() {
        super();
    }

    /**
     * M�todo para ejecutar una solicitud SOAP a un web services.
     *
     * Proceso el ingreso a sitios SSL.
     * Inicializa mensajes de error
     * Inicializa datos para la conexion.
     * Prepara a la conexion para enviar, recibir datos y tiempos de espera en conexion y de escritura.
     * Abre el puerto output y envia el xml a ser consultado y cierra el puerto.
     * Pregunta el estado de la respuesta.
     * Si la respuesta es HTTP_OK estado html 200 "respuesta ok del servidor consultado"
     *  Lee el contendio del imputStream
     * Caso contrario
     *  Lee el contenido del imputStream de Error
     *
     * Consume el contenido del imputStream y pasa a un respuestaSOAP
     * Cierra la conexion al servidor.
     *
     * Si existio un error en el servidor lo notifica
     * Devuelve el valor de la consulta al web service.
     *
     * @return
     * @throws Exception
     *
     */
    public String ejecutarConsultaWebService() throws Exception {
        setFechaInicio(new Date());
        tratamientSSL();

        setMensajeError(null);
        setXMLRespuesta("");
        String responseString = "";
        InputStream inputStream = null;

        HttpURLConnection connection = generarConexion();
        connection.setDoOutput(true);
        connection.setDoInput(true);
        connection.setConnectTimeout(getTimeOut());
        connection.setReadTimeout(getTimeOut());

        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(connection.getOutputStream());
        outputStreamWriter.write(getXMLConsulta());
        outputStreamWriter.close();

        setHTTPEstado(((HttpURLConnection) connection).getResponseCode());

        if (getHTTPEstado() != HttpURLConnection.HTTP_OK)
            inputStream = ((HttpURLConnection) connection).getErrorStream();
        else
            inputStream = connection.getInputStream();

        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

        while ((responseString = bufferedReader.readLine()) != null)
            setXMLRespuesta(getXMLRespuesta() + responseString);

        bufferedReader.close();
        setFechaFin(new Date());

        if (getHTTPEstado() != HttpURLConnection.HTTP_OK) {
            throw new Exception(String.valueOf(getHTTPEstado()));
        }

        creaDocument();
        return getXMLRespuesta();
    }

    /**Metodo para crear una nueva conexion.
     *
     * Se la puede sobrecargar.
     *
     * @return
     * @throws MalformedURLException
     * @throws IOException
     */
    public HttpURLConnection generarConexion() throws MalformedURLException, IOException {
        URL url = new URL(getURLConsulta());
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        return connection;
    }

    /**
     * M�todo para no comprobar el SSL de un servidor.
     *
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     * @throws Exception
     */
    public void tratamientSSL() throws Exception {
        TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            public void checkClientTrusted(X509Certificate[] certs, String authType) {
            }

            public void checkServerTrusted(X509Certificate[] certs, String authType) {
            }
        }
        };

        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        HostnameVerifier allHostsValid = new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
    }

    /**
     * M�todo para convertir en un Document, objeto contenedor de un XML.
     *     
     * @return
     */
    private void creaDocument() throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        InputSource is = new InputSource(new StringReader(getXMLRespuesta()));
        setXMLDocument(db.parse(is));
    }

}

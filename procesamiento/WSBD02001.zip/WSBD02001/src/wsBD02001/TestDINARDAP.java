package wsBD02001;

import java.io.IOException;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.jasypt.contrib.org.apache.commons.codec_1_3.binary.Base64;

import wsBD02001.com.SolicitaWebServicesURL;


/** Objeto para probar el consumo del WEB services.
 *
 * @author Omar Velez o.velez@jardinazuayo.fin.ec
 *
 */
public class TestDINARDAP {
    public TestDINARDAP() {
        super();
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        SolicitaWebServicesURL solicitaWebServicesURL = new SolicitaWebServicesURL() {

            public HttpURLConnection generarConexion() throws MalformedURLException, IOException {
                URL url = new URL(getURLConsulta());
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("SOAPACTION", "consultacomportamientocliente");
                String credentials = "COOPJARDINAZUAYO:Coopjardinazuayo";
                String basicAuth = "Basic " + new String(Base64.encodeBase64(credentials.getBytes()));
                connection.setRequestProperty("Authorization", basicAuth);
                return connection;
            }
        };

        solicitaWebServicesURL.setTimeOut(30000);
        solicitaWebServicesURL.setURLConsulta("https://ws.registrocrediticio.gob.ec/openerp/soap/COOPERATIVADEAHORROYCREDITOJARDINAZUAYO/openerp-consulta-comportamiento-cliente-20.consulta_comportamiento_cliente.229");
        solicitaWebServicesURL.setXMLConsulta("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\"><soapenv:Header><xs:consultacupostarjetascredito>?</xs:consultacupostarjetascredito></soapenv:Header><soapenv:Body><xs:request><xs:NUMERODOCUMENTO>0102581709</xs:NUMERODOCUMENTO><xs:TIPODOCUMENTO>C</xs:TIPODOCUMENTO></xs:request></soapenv:Body></soapenv:Envelope>");

        try {
            solicitaWebServicesURL.ejecutarConsultaWebService();
        } catch (Exception e) {
            System.out.println("Error en la solicitud web service " + e.toString());
        }
        System.out.println(solicitaWebServicesURL.toString());
    }
}

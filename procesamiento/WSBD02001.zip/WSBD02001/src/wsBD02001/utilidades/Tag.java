package wsBD02001.utilidades;


/** Objeto para generar tag de archivos xml.
 *
 * @author omar velez o.velez@jardinazuayo.fin.ec
 *
 */
public class Tag {
    public static final String INICIO_PARAMETRO="<![cdata[";
    public static final String FIN_PARAMETRO="]]>";
    
    public Tag() {
        super();
    }

    /**Metodo para generar un tag.
     *
     * @param nombreCampo
     * @return
     */
    public static String tag(String nombreCampo) {
        nombreCampo = (nombreCampo == null) ? "" : nombreCampo.trim();
        return "<" + nombreCampo + ">";
    }

    /** Metodo para crear el parametro de cierre de tag.
     *
     * @param nombreCampo
     * @return
     */
    public static String tagCierre(String nombreCampo) {
        nombreCampo = (nombreCampo == null) ? "" : nombreCampo.trim();
        return "</" + nombreCampo + ">";
    }

    /** Metodo para tener un tag.
     *
     * @param nombreCampo
     * @param contenido
     * @return
     */
    public static String tag(String nombreCampo, String contenido) {
        contenido = (contenido == null) ? "" : contenido.trim();
        return tag(nombreCampo) + contenido + tagCierre(nombreCampo);
    }

    /** Metodo para tener un tag.
     *
     * @param nombreCampo
     * @param contenido
     * @return
     */
    public static String tag(String nombreCampo, Integer contenido) {
        String contenidoSTR = contenido.toString();
        return tag(nombreCampo) + contenidoSTR + tagCierre(nombreCampo);
    }
    
    
}

